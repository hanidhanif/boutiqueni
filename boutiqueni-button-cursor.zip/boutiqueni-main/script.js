const navbar=document.getElementById('navbar');
const menu=document.getElementById('menuToggle');
const back=document.getElementById('backTop');
menu.addEventListener('click',()=>navbar.classList.toggle('open'));
document.querySelectorAll('nav a').forEach(a=>a.addEventListener('click',()=>navbar.classList.remove('open')));
window.addEventListener('scroll',()=>back.classList.toggle('show',scrollY>450));
back.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');observer.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));


// Auto-scroll: mulai setelah 2 detik tanpa aktivitas user.
(() => {
  const IDLE_DELAY = 2000;
  const SCROLL_STEP = 2.1;
  const SCROLL_INTERVAL = 16;
  const TOP_RESET_DURATION = 450;

  let idleTimer;
  let autoScrollTimer = null;
  let resettingToTop = false;

  const stopAutoScroll = () => {
    if (autoScrollTimer) {
      clearInterval(autoScrollTimer);
      autoScrollTimer = null;
    }
  };

  const startAutoScroll = () => {
    stopAutoScroll();
    if (document.documentElement.scrollHeight <= window.innerHeight) return;

    autoScrollTimer = setInterval(() => {
      if (resettingToTop) return;

      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (window.scrollY >= maxScroll - 2) {
        resettingToTop = true;
        stopAutoScroll();
        window.scrollTo({ top: 0, behavior: 'smooth' });

        setTimeout(() => {
          resettingToTop = false;
          startAutoScroll();
        }, TOP_RESET_DURATION);
        return;
      }

      window.scrollBy(0, SCROLL_STEP);
    }, SCROLL_INTERVAL);
  };

  const registerActivity = () => {
    stopAutoScroll();
    resettingToTop = false;
    clearTimeout(idleTimer);
    idleTimer = setTimeout(startAutoScroll, IDLE_DELAY);
  };

  ['mousemove', 'mousedown', 'wheel', 'touchstart', 'touchmove', 'keydown', 'pointerdown'].forEach(eventName => {
    window.addEventListener(eventName, registerActivity, { passive: true });
  });

  window.addEventListener('scroll', () => {
    if (!resettingToTop && autoScrollTimer) return;
    registerActivity();
  }, { passive: true });

  registerActivity();
})();


// Cute button cursor + button trail
(() => {
  const cursor = document.createElement('div');
  cursor.className = 'button-cursor';
  cursor.setAttribute('aria-hidden', 'true');
  cursor.innerHTML = '<span></span><span></span><span></span><span></span>';
  document.body.appendChild(cursor);

  const colors = ['pink', 'cream', 'burgundy', 'rose', 'brown'];
  let lastX = -100;
  let lastY = -100;
  let lastTrail = 0;

  function moveButton(x, y) {
    cursor.style.left = x + 'px';
    cursor.style.top = y + 'px';
    cursor.classList.add('is-visible');
  }

  function makeTrail(x, y) {
    const now = performance.now();
    if (now - lastTrail < 85) return;
    lastTrail = now;

    const trail = document.createElement('span');
    trail.className = 'button-trail ' + colors[Math.floor(Math.random() * colors.length)];
    trail.style.left = x + 'px';
    trail.style.top = y + 'px';
    trail.innerHTML = '<i></i><i></i><i></i><i></i>';
    document.body.appendChild(trail);
    setTimeout(() => trail.remove(), 850);
  }

  function handlePointer(x, y) {
    moveButton(x, y);
    const distance = Math.hypot(x - lastX, y - lastY);
    if (distance > 8) makeTrail(x, y);
    lastX = x;
    lastY = y;
  }

  window.addEventListener('mousemove', e => handlePointer(e.clientX, e.clientY), { passive: true });
  window.addEventListener('pointermove', e => {
    if (e.pointerType === 'touch') handlePointer(e.clientX, e.clientY);
  }, { passive: true });

  window.addEventListener('mouseleave', () => cursor.classList.remove('is-visible'));
  window.addEventListener('mouseenter', e => moveButton(e.clientX, e.clientY));

  // Hide the custom pointer when the pointer leaves the page or on coarse touch devices.
  const coarse = window.matchMedia('(pointer: coarse)').matches;
  if (coarse) cursor.classList.add('touch-mode');
})();
